var Record = artifacts.require("./Record.sol");

module.exports = function(deployer) {
  deployer.deploy(Record);
};
